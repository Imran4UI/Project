import React from "react";
import clothes from '../assets/imgs/clothes.png';
import carousel1 from '../assets/imgs/carousel1.jpg';
import carousel2 from '../assets/imgs/carousel2.jpg';

class HeadCarousel extends React.Component{
    render() {
        return (
            <React.Fragment>
                <section className="mb-3">
                    <div className="carousel slide" data-ride="carousel" id="slider">
                        <ol className="carousel-indicators">
                            <li data-target="#slider" data-slide-to="0" className="active"/>
                            <li data-target="#slider" data-slide-to="1"/>
                            <li data-target="#slider" data-slide-to="2"/>
                        </ol>
                        <div className="carousel-inner">
                            <div className="carousel-item active">
                                <img src={clothes} className="img-fluid"/>
                                    <div className="carousel-caption text-left ">
                                        <h4 className="display-4 animated jackInTheBox">DEGREES OF REGULATION</h4>
                                        <div className="animated zoomIn delay-1s">
                                            <p className="lead">Lorem ipsum, dolor sit amet consectetur adipisicing
                                                elit. Exercitationem
                                                corrupti velit excepturi tempora incidunt repellat, animi accusantium et
                                                autem in
                                                temporibus. At nostrum facere mollitia, fuga praesentium quae.</p>
                                            <button className="btn btn-light btn-sm">SHOP FOR TEMP</button>
                                        </div>
                                    </div>
                            </div>

                            <div className="carousel-item">
                                <img src={carousel1} className="img-fluid"/>
                                    <div className="carousel-caption">
                                        <h4 className="display-4 animated jackInTheBox">Cheers for this Moment!!!</h4>
                                        <div className="animated zoomIn delay-1s">
                                            <p className="lead">Lorem ipsum dolor sit amet consectetur, adipisicing
                                                elit. Architecto enim
                                                harum beatae ipsa atque. Eius cupiditate, tempora earum praesentium
                                                tenetur sunt
                                                aspernatur quas, numquam, voluptas optio possimus fugit.</p>
                                            <button className="btn btn-dark btn-sm">Read More</button>
                                        </div>
                                    </div>
                            </div>

                            <div className="carousel-item">
                                <img src={carousel2}
                                     className="w-100" alt=""/>
                                    <div className="carousel-caption text-right">
                                        <h4 className="display-4 animated jackInTheBox">Let's Rock The Party!!</h4>
                                        <div className="animated zoomIn delay-1s">
                                            <p className="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                                Enim illum dicta
                                                aliquid aperiam impedit corporis, tempore, obcaecati recusandae sit
                                                rerum id corrupti
                                                sequi, voluptatem est veritatis earum. Odio?</p>
                                            <button className="btn btn-success btn-sm">Read More</button>
                                        </div>
                                    </div>
                            </div>

                            <a className="carousel-control-prev" href="#slider" role="button" data-slide="prev">
                                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span className="sr-only">Previous</span>
                            </a>
                            <a className="carousel-control-next" href="#slider" role="button" data-slide="next">
                                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                                <span className="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </section>

            </React.Fragment>
        );
    }
}
export default HeadCarousel;