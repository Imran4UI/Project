import React from "react";
import shoes from '../assets/imgs/shoes.png';
import Watch from '../assets/imgs/Watch.jpg';
import Watch1 from '../assets/imgs/Watch1.jpg';

class Section1 extends React.Component{
    render() {
        return (
            <React.Fragment>
                <div className="container mb-5">
                    <h2><b>NEW ARRIVALS</b></h2>
                    <div className="row">
                        <div className="col-md-6 text-center">
                            <img src={shoes} className="img-fluid" alt=""/>
                            <button className="btn btn-dark ">SHOP NOW</button>
                        </div>
                        <div className="col-md-3">
                            <div className="card">
                                <img src={Watch} alt="" className="img-fluid"/>
                                <div className="card-body">
                                    <span>Watch For Mens</span><br/>
                                    <span>BRAND : <b>Chopard</b></span>
                                    <button className="btn btn-grey btn-sm ">SHOP NOW</button><br/>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-3">
                            <div className="card">
                                <img src={Watch} alt="" className="img-fluid"/>
                                <div className="card-body">
                                    <span>Watch For Mens</span><br/>
                                    <span>BRAND : <b>Chopard</b></span>
                                    <button className="btn btn-grey btn-sm ">SHOP NOW</button><br/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container mB-3">
                    <div className="row">
                        <div className="col-md-3">
                            <div className="card">
                                <img src={Watch} alt="" className="img-fluid"/>
                                <div className="card-body">
                                    <span>Watch For Mens</span><br/>
                                    <span>BRAND : <b>Chopard</b></span>
                                    <button className="btn btn-grey btn-sm ">SHOP NOW</button><br/>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-3">
                            <div className="card">
                                <img src={Watch} alt="" className="img-fluid"/>
                                <div className="card-body">
                                    <span>Watch For Mens</span><br/>
                                    <span>BRAND : <b>Chopard</b></span>
                                    <button className="btn btn-grey btn-sm ">SHOP NOW</button><br/>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 text-center">
                            <img src={shoes} className="img-fluid" alt=""/>
                            <button className="btn btn-dark  ">SHOP NOW</button>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}
export default Section1;