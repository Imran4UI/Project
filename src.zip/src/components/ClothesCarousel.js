import React from "react";
import Watch from "../assets/imgs/Watch.jpg";

class ClothesCarousel extends React.Component{
    render() {
        return (
            <React.Fragment>
                <div className="container my-3">
                    <h2><b>CLOTHES FOR MEN</b></h2>
                    <div className="carousel-slide" data-ride="carousel">
                        <div className="carousel-inner">
                            <div className="row">
                                <div className="col-md-3">
                                    <div className="card">
                                        <img src={Watch} alt="" className="img-fluid"/>
                                        <div className="card-body">
                                            <span>Watch For Mens</span><br/>
                                            <span>BRAND : <b>Chopard</b></span>
                                            <button className="btn btn-grey btn-sm ">SHOP NOW</button><br/>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <div className="card">
                                        <img src={Watch} alt="" className="img-fluid"/>
                                        <div className="card-body">
                                            <span>Watch For Mens</span><br/>
                                            <span>BRAND : <b>Chopard</b></span>
                                            <button className="btn btn-grey btn-sm ">SHOP NOW</button><br/>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <div className="card">
                                        <img src={Watch} alt="" className="img-fluid"/>
                                        <div className="card-body">
                                            <span>Watch For Mens</span><br/>
                                            <span>BRAND : <b>Chopard</b></span>
                                            <button className="btn btn-grey btn-sm ">SHOP NOW</button><br/>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <div className="card">
                                        <img src={Watch} alt="" className="img-fluid"/>
                                        <div className="card-body">
                                            <span>Watch For Mens</span><br/>
                                            <span>BRAND : <b>Chopard</b></span>
                                            <button className="btn btn-grey btn-sm ">SHOP NOW</button><br/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container">
                    <div className="row">
                        <div className="col-md-6">

                        </div>
                        <div className="col-md-3">

                        </div>
                        <div className="col-md-3">

                        </div>
                    </div>
                </div>

            </React.Fragment>
        );
    }

}
export default ClothesCarousel;