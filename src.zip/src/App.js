import React from 'react';
import './App.css';
import Navbar from "./components/Navbar";
import HeadCarousel from "./components/HeadCarousel";
import Section1 from "./components/Section1";
import ClothesCarousel from "./components/ClothesCarousel";

function App() {
    return (
        <div className="App">
            <Navbar/>
            <HeadCarousel/>
            <Section1/>
            <ClothesCarousel/>
        </div>
    );
}

export default App;
